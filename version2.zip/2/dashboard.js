/* ══════════════════════════════════════════
   DONNÉES — Patients
══════════════════════════════════════════ */

const PATIENTS = [
  {
    id:        1,
    nom:       'Jean Dupont',
    age:       75,
    pathologie:'Diabète',
    avatar:    'https://i.pravatar.cc/40?img=1'
  },
  {
    id:        2,
    nom:       'Marie Martin',
    age:       81,
    pathologie:'Hypertension',
    avatar:    'https://i.pravatar.cc/40?img=2'
  },
  {
    id:        3,
    nom:       'Paul Bernard',
    age:       70,
    pathologie:'Troubles mémoire',
    avatar:    'https://i.pravatar.cc/40?img=3'
  }
];

/* ══════════════════════════════════════════
   DONNÉES — RDV du jour
══════════════════════════════════════════ */

const RDV_JOUR = [
  { heure: '09:30', patient: 'Jean Dupont',  type: 'Contrôle glycémie' },
  { heure: '11:00', patient: 'Marie Martin', type: 'Prise de tension'  },
  { heure: '14:30', patient: 'Paul Bernard', type: 'Séance mémoire'    }
];

/* ══════════════════════════════════════════
   DONNÉES — Alertes
══════════════════════════════════════════ */

const ALERTES = [
  {
    niveau: 'rouge',
    texte:  'Jean Dupont — glycémie élevée',
    sub:    'Mesure de ce matin : 2,1 g/L'
  },
  {
    niveau: 'amber',
    texte:  'Renouvellement ordonnance',
    sub:    'Marie Martin — expire le 12/03'
  }
];

/* ══════════════════════════════════════════
   RENDU — Liste patients
══════════════════════════════════════════ */

function renderPatients() {
  const container = document.getElementById('patientList');
  if (!container) return;

  container.innerHTML = PATIENTS.map(p => `
    <div class="patient-item" onclick="openPatient('${escapeHtml(p.nom)}', '${p.age}', '${escapeHtml(p.pathologie)}')">
      <img src="${p.avatar}" alt="${escapeHtml(p.nom)}">
      <div class="patient-item-info">
        <div class="patient-item-name">${escapeHtml(p.nom)}</div>
        <div class="patient-item-detail">${p.age} ans · ${escapeHtml(p.pathologie)}</div>
      </div>
      <div class="patient-item-badge">${escapeHtml(p.pathologie)}</div>
    </div>
  `).join('');

  const countEl = document.getElementById('patientCount');
  if (countEl) countEl.textContent = `${PATIENTS.length} patients suivis`;

  const statEl = document.getElementById('statPatients');
  if (statEl) statEl.textContent = PATIENTS.length;
}

/* ══════════════════════════════════════════
   RENDU — Liste RDV
══════════════════════════════════════════ */

function renderRdv() {
  const container = document.getElementById('rdvList');
  if (!container) return;

  if (RDV_JOUR.length === 0) {
    container.innerHTML = '<div style="font-size:13px;color:var(--muted);text-align:center;padding:16px 0">Aucun RDV aujourd\'hui</div>';
    return;
  }

  container.innerHTML = RDV_JOUR.map(r => `
    <div class="rdv-item">
      <div class="rdv-time">${escapeHtml(r.heure)}</div>
      <div class="rdv-divider"></div>
      <div class="rdv-info">
        <div class="rdv-patient">${escapeHtml(r.patient)}</div>
        <div class="rdv-type">${escapeHtml(r.type)}</div>
      </div>
    </div>
  `).join('');

  // Met à jour les stats
  const statRdvEl    = document.getElementById('statRdv');
  const statProchain = document.getElementById('statProchain');
  if (statRdvEl)    statRdvEl.textContent    = RDV_JOUR.length;
  if (statProchain) statProchain.textContent = RDV_JOUR[0]?.heure ?? '—';
}

/* ══════════════════════════════════════════
   RENDU — Alertes
══════════════════════════════════════════ */

function renderAlertes() {
  const container = document.getElementById('alerteList');
  if (!container) return;

  if (ALERTES.length === 0) {
    container.innerHTML = '<div style="font-size:13px;color:var(--muted);text-align:center;padding:16px 0">Aucune alerte</div>';
    return;
  }

  container.innerHTML = ALERTES.map(a => `
    <div class="alerte-item alerte-${a.niveau}">
      <div class="alerte-dot"></div>
      <div>
        <div class="alerte-text">${escapeHtml(a.texte)}</div>
        <div class="alerte-sub">${escapeHtml(a.sub)}</div>
      </div>
    </div>
  `).join('');

  const countEl = document.getElementById('alerteCount');
  if (countEl) countEl.textContent = `${ALERTES.length} alerte${ALERTES.length > 1 ? 's' : ''} active${ALERTES.length > 1 ? 's' : ''}`;

  const statEl = document.getElementById('statAlertes');
  if (statEl) statEl.textContent = ALERTES.length;
}

/* ══════════════════════════════════════════
   RENDU — Date courante dans le header
══════════════════════════════════════════ */

function renderDate() {
  const el = document.getElementById('currentDate');
  if (!el) return;
  el.textContent = new Date().toLocaleDateString('fr-FR', {
    weekday: 'long',
    day:     'numeric',
    month:   'long',
    year:    'numeric'
  });
}

/* ══════════════════════════════════════════
   NAVIGATION
══════════════════════════════════════════ */

/** Recharge le dashboard (page courante) */
function goDashboard() {
  setActiveNav(0);
  window.location.href = 'dashboard.html';
}

/** Ouvre la page du calendrier */
function openCalendar() {
  setActiveNav(1);
  window.location.href = 'calendar.html';
}

/** Ouvre le quiz mémoire */
function openQuiz() {
  setActiveNav(2);
  window.location.href = 'quiz.html';
}

/** Ouvre la liste complète des patients */
function openPatientList() {
  setActiveNav(3);
  window.location.href = 'patients.html';
}

/** Ouvre la fiche d'un patient spécifique */
function openPatient(nom, age, pathologie) {
  // Passe les données via URL (ou localStorage selon architecture)
  const params = new URLSearchParams({ nom, age, pathologie });
  window.location.href = 'patient.html?' + params.toString();
}

/** Ouvre la création d'un nouveau RDV */
function openNewRdv() {
  window.location.href = 'calendar.html?new=1';
}

/**
 * Met à jour l'état actif dans la nav mobile.
 * @param {number} index - index du bouton actif (0=accueil, 1=cal, 2=quiz, 3=patients)
 */
function setActiveNav(index) {
  const items = document.querySelectorAll('.mobile-nav-item');
  items.forEach((item, i) => {
    item.classList.toggle('active', i === index);
  });
}

/* ══════════════════════════════════════════
   UTILITAIRES
══════════════════════════════════════════ */

/** Échappe les caractères HTML pour éviter les injections XSS. */
function escapeHtml(str) {
  return String(str)
    .replace(/&/g,  '&amp;')
    .replace(/</g,  '&lt;')
    .replace(/>/g,  '&gt;')
    .replace(/"/g,  '&quot;')
    .replace(/'/g,  '&#039;');
}

/* ══════════════════════════════════════════
   POINT D'ENTRÉE
══════════════════════════════════════════ */

document.addEventListener('DOMContentLoaded', function () {
  renderDate();
  renderPatients();
  renderRdv();
  renderAlertes();
});